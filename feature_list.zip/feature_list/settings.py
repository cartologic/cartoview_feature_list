__author__ = 'kamal'
import os, sys
import feature_list

current_folder = os.path.dirname(feature_list.__file__)